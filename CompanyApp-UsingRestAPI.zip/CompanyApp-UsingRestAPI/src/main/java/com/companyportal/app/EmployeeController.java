package com.companyportal.app;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.companyportal.app.entity.Employee;
import com.companyportal.app.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
    @GetMapping("/")
    public String home(){
    	return "homepage";
    }
    
    @GetMapping("/gotohome")
    public String homepage() {
    	return "homepage";
    }
  /* @GetMapping("/saveData")
	@ResponseBody
	public String displayRegistrationForm(Model model) {
		Employee employee = new Employee();	
		
		model.addAttribute("employee", employee);
		return "employeeform";
    }*/
    @PostMapping(value="/saveEmployee",consumes=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public Employee saveEmployeeData(@RequestBody Employee employee) {
		employeeService.saveEmployeeData(employee);
		return employee;
	}
    
    @GetMapping(value="/getEmployeesDetail",consumes=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Employee> getEmployeesData(Model model) {
		List<Employee> employeeList = employeeService.getEmployeesData();
				
		model.addAttribute("employeeList", employeeList);
		return employeeList;
	}
 
    @PutMapping(value="/editEmployee")
   	@ResponseBody
	public String updateEmployee(@RequestBody Employee employee) {
		String result=null;
		Employee e=new Employee();
		BeanUtils.copyProperties(employee,e);
	    result=employeeService.modifyEmployeeByNo(e);
		return result;
	
	}
    @DeleteMapping("/deleteEmployee/{employeeId}")
   	@ResponseBody
	public   String   removeEmployee(@PathVariable int employeeId) {
		String result=null;
		Employee e=new Employee();
		e.setEmployeeId(employeeId);
		 //use service
		result=employeeService.removeEmpByNo(employeeId);
		//add result to flash attribute
		 return result;
	}

	@GetMapping(value = "/searchEmployee/{string}")
	@ResponseBody
	public List<Employee> searchData(@PathVariable("string")String string){
	List<Employee> employeesList=employeeService.getSearchData(string);
	return employeesList;
	//return new ModelAndView("employeelist","employeeList",employeesList);
	}
	
	@GetMapping("/msg")
	@ResponseBody
	public String displayMessage() {
		return "Welcome";
	}
	
}
