package com.companyportal.app.dao;

import java.util.List;

import com.companyportal.app.entity.Employee;

public interface EmployeeDao {

	public void saveEmployeeData(Employee employee);

	public List<Employee> getEmployeesData();

	public Employee getEmpById(int empNo);

	public int updateEmployee(Employee employee);

	public int deleteEmpById(int eno);

	public List<Employee> getSearchData(String string);

}
