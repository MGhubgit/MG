package com.companyportal.app.service;

import java.util.List;

import com.companyportal.app.entity.Employee;

public interface EmployeeService {

	public void saveEmployeeData(Employee employee);

	public List<Employee> getEmployeesData();

	public Employee fetchEmpByNo(int empNo);

	public String modifyEmployeeByNo(Employee employee);

	public String removeEmpByNo(int eno);

	public List<Employee> getSearchData(String string);
}
