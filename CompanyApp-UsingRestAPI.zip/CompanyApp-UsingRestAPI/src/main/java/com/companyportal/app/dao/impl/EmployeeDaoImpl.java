package com.companyportal.app.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.companyportal.app.dao.EmployeeDao;
import com.companyportal.app.entity.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	
	@Autowired
	private SessionFactory sessionFactory;



	@Override
	public void saveEmployeeData(Employee employee) {
	Session session = sessionFactory.openSession();
	session.beginTransaction();
	session.persist(employee);
	session.getTransaction().commit();
	session.close();
	}

	@Override
	public List<Employee> getEmployeesData() {
	List<Employee> empList=new ArrayList<Employee>();
	Session session = sessionFactory.openSession();
	session.beginTransaction();
	empList=session.createQuery("from Employee").list();
	session.getTransaction().commit();
	session.close();
	return empList;
	}

	@Override
	public Employee getEmpById(int empNo) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		/*session.createQuery("from Employee where employeeId=:empNo");
		session.getTransaction().commit();
		session.close();*/
		Session ses = sessionFactory.openSession();
		ses.beginTransaction();
		Employee e= (Employee)ses.get(Employee.class, empNo);
		 System.out.println(e);
		return e;
	}

	@Override
	public int updateEmployee(Employee employee) {
		Session session = sessionFactory.openSession();
		System.out.println("EmployeeDaoImpl.updateEmployee()");
	  /* Employee emp=new Employee();
	     
		emp.setName(employee.getName());
		emp.setProject(employee.getProject());
		emp.setMailId(employee.getMailId());
		emp.setPhoneNo(employee.getPhoneNo());
		session.beginTransaction();
	    session.update(emp);
	    System.out.println(emp);
	    session.getTransaction().commit();
		session.close();
			  */
		Employee emp= (Employee)session.get(Employee.class, employee.getEmployeeId());
		emp.setEmployeeId(employee.getEmployeeId());
		emp.setName(employee.getName());
		emp.setProject(employee.getProject());
		emp.setMailId(employee.getMailId());
		emp.setPhoneNo(employee.getPhoneNo());
		session.update(emp);
		session.beginTransaction();
		session.getTransaction().commit();
	   
		return 0;
	}

	@Override
	public int deleteEmpById(int eno) {
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		 Employee e1= (Employee)session.get(Employee.class, eno);
		 if (e1!=null) {
		 session.delete(e1);
		 session.getTransaction().commit();
		 return 1;
	}else
	return 0;
	}

	@Override
	public List<Employee> getSearchData(String string) {
	Session session = sessionFactory.openSession();
	Query<Employee> query = session.createQuery("from Employee where name like :string");
	string = "%" + string + "%";
	query.setParameter("string", string);
	List<Employee> list = query.list();
	session.close();
	return list;
	}

}
