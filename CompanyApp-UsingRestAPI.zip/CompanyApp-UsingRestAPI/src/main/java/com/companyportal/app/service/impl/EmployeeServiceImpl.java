package com.companyportal.app.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyportal.app.dao.EmployeeDao;
import com.companyportal.app.entity.Employee;
import com.companyportal.app.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	private static int count=0;
	
	@Autowired
	private EmployeeDao employeeDao;
	
	@Override
	public void saveEmployeeData(Employee employee) {
		employee.setEmployeeId(count++);
		
		employeeDao.saveEmployeeData(employee);
	}

	@Override
	public List<Employee> getEmployeesData() {
		
		return employeeDao.getEmployeesData();
	}

	@Override
	public Employee fetchEmpByNo(int empNo) {		
		return employeeDao.getEmpById(empNo);
		
	}

	@Override
	public String modifyEmployeeByNo(Employee employee) {
		// TODO Auto-generated method stub
		System.out.println("EmployeeServiceImpl.modifyEmployeeByNo()");
		int count =employeeDao.updateEmployee(employee);
		return count==0?employee.getEmployeeId()+" employee details found and update":employee.getEmployeeId() +"  employee details not found to update";
	}

	@Override
	public String removeEmpByNo(int eno) {
		int count=employeeDao.deleteEmpById(eno);
		return count==0?eno+" emp not found for deletion":eno+" emp found and deleted";
		}

	@Override
	public List<Employee> getSearchData(String string) {
	return employeeDao.getSearchData(string);
	}

}
