package com.food.java.service;

import java.util.List;

import com.food.java.dto.FoodItemResponseDTO;
import com.food.java.dto.FoodIdRequestDTO;
import com.food.java.entity.FoodItem;

public interface FoodItemService {

	public List<FoodItemResponseDTO> getFoodList();

	public List<FoodItemResponseDTO> getFoodListByName(String foodName);

	public List<FoodItemResponseDTO> getFoodById(FoodIdRequestDTO dto);

}
