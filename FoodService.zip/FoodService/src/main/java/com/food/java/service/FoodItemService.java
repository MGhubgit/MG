package com.food.java.service;

import java.util.List;

import com.food.java.dto.FoodItemResponseDTO;

public interface FoodItemService {

	public List<FoodItemResponseDTO> getFoodList();

	public List<FoodItemResponseDTO> getFoodListByName(String foodName);

}
