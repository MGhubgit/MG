package com.food.java.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.java.dto.FoodItemResponseDTO;
import com.food.java.dto.FoodIdRequestDTO;
import com.food.java.entity.FoodItem;
import com.food.java.repository.FoodItemRepository;
import com.java.exception.MenuNotFoundException;


@Service
public class FoodItemServiceImpl implements FoodItemService {

	@Autowired
	private FoodItemRepository repository;

	//-----------------Get Food List By ---------------------
	
	/*
	 * @Override public List<FoodItemResponseDTO> getFoodList() {
	 * 
	 * List<FoodItemResponseDTO> list=new ArrayList<FoodItemResponseDTO>(); Iterator
	 * it=repository.findAll().iterator(); while(it.hasNext()) { FoodItemResponseDTO
	 * dto=new FoodItemResponseDTO(); BeanUtils.copyProperties(it.next(), dto);
	 * list.add(dto); } return list; }
	 */
	
	//-----------------Get Food List By Java8---------------------
	@Override
	public List<FoodItemResponseDTO> getFoodList() {

		List<FoodItemResponseDTO> list = new ArrayList<FoodItemResponseDTO>();
		((Collection<FoodItem>) repository.findAll()).stream().forEach(list1 -> {
			FoodItemResponseDTO dto = new FoodItemResponseDTO();
			BeanUtils.copyProperties(list1, dto);
			list.add(dto);
		});
		return list;
	}
	//--------------Search food item by food name ------------------
	
	/*
	 * @Override public List<FoodItemResponseDTO> getFoodListByName(String foodName)
	 * { System.out.println(foodName); 
	 * List<FoodItemResponseDTO> list=new ArrayList<FoodItemResponseDTO>(); 
	 * Iterator it=repository.findByfoodNameContaining(foodName).iterator();
	 * 
	 * while(it.hasNext()) { 
	 * FoodItemResponseDTO dto=new FoodItemResponseDTO();
	 * BeanUtils.copyProperties(it.next(), dto); 
	 * list.add(dto); }
	 * System.out.println(list); 
	 * if(list.isEmpty()) throw new MenuNotFoundException("No Food with the name: "+foodName); 
	 * return list;
	 * }
	 */
   
	//--------------Search food item by food name Using Java8------------------
	@Override
	public List<FoodItemResponseDTO> getFoodListByName(String foodName) {
	
		List<FoodItemResponseDTO> list = new ArrayList<FoodItemResponseDTO>();
		
		repository.findByfoodNameContaining(foodName).stream().forEach(list1 -> {
			FoodItemResponseDTO dto = new FoodItemResponseDTO();
			BeanUtils.copyProperties(list1, dto);
			list.add(dto);
		});
		if (list.isEmpty())
			throw new MenuNotFoundException("No Food with the name: " + foodName);
		return list;

	}

/*	@Override
	public List<FoodItemResponseDTO> getFoodById(FoodIdRequestDTO dto) {
		List<FoodItemResponseDTO> list = new ArrayList<FoodItemResponseDTO>();
		Iterator foodlist = repository.findAllById(dto.getFoodItemId()).iterator();
		
		while (foodlist.hasNext()) {
			FoodItemResponseDTO foodDTO = new FoodItemResponseDTO();
			BeanUtils.copyProperties(foodlist.next(), foodDTO);
			list.add(foodDTO);
		}
		return list;
	}*/
	
	@Override
	public List<FoodItemResponseDTO> getFoodById(FoodIdRequestDTO dto) {
		List<FoodItemResponseDTO> list = new ArrayList<FoodItemResponseDTO>();
		((Collection<FoodItem>) repository.findAllById(dto.getFoodItemId())).stream().forEach(foodlist-> {
	
			FoodItemResponseDTO foodDTO = new FoodItemResponseDTO();
			BeanUtils.copyProperties(foodlist, foodDTO);
			list.add(foodDTO);
		});
		return list;
	}
}
