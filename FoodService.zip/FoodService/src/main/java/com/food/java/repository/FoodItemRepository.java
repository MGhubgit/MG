package com.food.java.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.food.java.entity.FoodItem;
@Repository
public interface FoodItemRepository extends CrudRepository<FoodItem, Integer> {

	List<FoodItem> findByfoodNameLike(String foodname);
	//public FoodItemResponseDTO findByNameContaining(String foodname);

	List<FoodItem> findByfoodNameContaining(String foodName);
}
