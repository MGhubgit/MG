package com.food.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.food.java.dto.FoodIdRequestDTO;
import com.food.java.dto.FoodItemResponseDTO;
import com.food.java.service.FoodItemService;
import com.java.exception.MenuNotFoundException;


@RestController
public class FoodItemController {

	@Autowired
	private FoodItemService service;

	//-------------Get Menu List------------------
	
	@GetMapping("/MenuList")
	public List<FoodItemResponseDTO> getFoodList() {
		List<FoodItemResponseDTO> list = service.getFoodList();
		if (list.isEmpty()) {
			throw new MenuNotFoundException("Menu Not Found");
		} else
			return list;
	}
	
    //---------------Find Food Item by Name----------
	
	@GetMapping("/Item")
	public List<FoodItemResponseDTO> getItemByName(@RequestParam String foodName) {
		List<FoodItemResponseDTO> fooditemlist = service.getFoodListByName(foodName);
		if (fooditemlist.isEmpty()) {
			throw new MenuNotFoundException("Menu Not Found");
		} else
			return fooditemlist;
	}
	@PostMapping("/Food")
	public List<FoodItemResponseDTO> getFoodItemById(@RequestBody FoodIdRequestDTO dto){
		return service.getFoodById(dto);
	}

}
