package com.food.java.dto;

public class FoodItemResponseDTO {
	private Integer foodItemId;
	private String foodName;
	private float price;
	private String foodType;

	public Integer getFoodItemId() {
		return foodItemId;
	}

	public void setFoodItemId(Integer foodItemId) {
		this.foodItemId = foodItemId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	@Override
	public String toString() {
		return "FoodItemResponseDTO [foodItemId=" + foodItemId + ", foodName=" + foodName + ", price=" + price
				+ ", foodType=" + foodType + "]";
	}
	

}
